create view region_centroid(geo) as
SELECT st_centroid(regiao.geom) AS geo
FROM regiao;

alter table region_centroid
    owner to postgres;

